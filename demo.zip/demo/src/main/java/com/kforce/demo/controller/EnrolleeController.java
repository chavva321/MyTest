package com.kforce.demo.controller;

import com.kforce.demo.model.Enrollee;
import com.kforce.demo.service.EnrolleeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("enrollee")
public class EnrolleeController {

    @Autowired
    EnrolleeService service;

    @PostMapping(value = "/save")
    public Enrollee save(@RequestBody Enrollee obj) {
        return service.save(obj);
    }

    @PostMapping(value = "/delete/{enrolleeId}")
    public void delete(@PathVariable("enrolleeId") Integer enrolleeId) {
        service.delete(enrolleeId);
    }
}
