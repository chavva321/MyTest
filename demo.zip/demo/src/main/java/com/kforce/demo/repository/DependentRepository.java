package com.kforce.demo.repository;

import com.kforce.demo.model.Dependent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface DependentRepository extends JpaRepository<Dependent, Integer> {

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "DELETE FROM DEPENDENT WHERE ENROLLEE_ID=:enrolleeId")
    void deleteByEnrollee(@Param("enrolleeId") Integer enrolleeId);
}
