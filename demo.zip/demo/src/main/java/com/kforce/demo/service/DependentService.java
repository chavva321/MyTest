package com.kforce.demo.service;

import com.kforce.demo.model.Dependent;
import com.kforce.demo.repository.DependentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DependentService {

    @Autowired
    DependentRepository repository;

    public Dependent save(Dependent obj) {
        return repository.save(obj);
    }

    public void delete(Integer enrolleeId) {
        repository.deleteByEnrollee(enrolleeId);
    }
}
