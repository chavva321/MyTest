package com.kforce.demo.controller;

import com.kforce.demo.model.Dependent;
import com.kforce.demo.service.DependentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("dependent")
public class DependentController {
    @Autowired
    DependentService service;

    @PostMapping(value = "/save")
    public Dependent save(@RequestBody Dependent obj) {
        return service.save(obj);
    }

    @PostMapping(value = "/delete/{enrolleeId}")
    public void delete(@PathVariable("enrolleeId") Integer enrolleeId) {
        service.delete(enrolleeId);
    }
}
