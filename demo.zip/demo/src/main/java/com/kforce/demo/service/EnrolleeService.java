package com.kforce.demo.service;

import com.kforce.demo.model.Enrollee;
import com.kforce.demo.repository.EnrolleeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EnrolleeService {

    @Autowired
    EnrolleeRepository repository;

    public Enrollee save(Enrollee obj) {
        return repository.save(obj);
    }

    public void delete(Integer enrolleeId) {
        repository.deleteById(enrolleeId);
    }
}
